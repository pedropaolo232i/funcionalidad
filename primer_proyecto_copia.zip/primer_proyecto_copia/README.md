# Primer proyecto Git

Bienvenido al proyecto.

Te saluda Luiggi.

## Stack Tecnológico

El proyecto trabajará usando

- Java 8
- Spring Boot 2
- JPA 2.2

## Autores

- Alvaro
- Luiggi
