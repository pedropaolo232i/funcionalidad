package com.cmaccusco.primerproyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
