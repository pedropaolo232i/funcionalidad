package com.cmaccusco.primerproyecto.repositorio;

public class RepositorioSaludo {
  
}
